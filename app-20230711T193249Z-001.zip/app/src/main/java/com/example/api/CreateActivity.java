package com.example.api;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.api.api.ApiClient;
import com.example.api.model.Phone;
import com.example.api.service.PhoneService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateActivity extends AppCompatActivity {

    private EditText edtPhoneName;
    private EditText edtPrice;
    private Button btnCreate;
    private PhoneService phoneService;
    private ImageView ivBack;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        
        edtPhoneName = findViewById(R.id.edtPhoneName);
        edtPrice = findViewById(R.id.edtCreatePrice);
        
        phoneService = ApiClient.getClient().create(PhoneService.class);

        ivBack = findViewById(R.id.ivCreateBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(CreateActivity.this, MainActivity.class);
                startActivity(back);
                finish();
            }
        });
        
        btnCreate = findViewById(R.id.btnCreate);
        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createPhone();
            }
        });
    }

    private void createPhone() {
        String phoneName = edtPhoneName.getText().toString();
        int phonePrice = Integer.parseInt(edtPrice.getText().toString());

        Phone phone = new Phone();
        phone.setPhoneName(phoneName);
        phone.setPrice(phonePrice);

        Call<Phone> call = phoneService.ceatePhone(phone);
        call.enqueue(new Callback<Phone>() {
            @Override
            public void onResponse(Call<Phone> call, Response<Phone> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(CreateActivity.this, "Berhasil menambahkan Data Phone", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(CreateActivity.this, "Gagal menambahkan Data Phone, error : " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Phone> call, Throwable t) {
                Toast.makeText(CreateActivity.this, "Gagal menambahkan Data Phone, error message : " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
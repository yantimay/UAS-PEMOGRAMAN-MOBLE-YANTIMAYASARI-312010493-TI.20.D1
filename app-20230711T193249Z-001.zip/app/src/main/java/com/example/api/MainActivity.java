package com.example.api;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btnGet;
    private Button btnCreate;
    private Button btnUpdate;
    private Button btnDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnGet = findViewById(R.id.btnGetMain);
        btnGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent get = new Intent(MainActivity.this, GetActivity.class);
                startActivity(get);
                finish();
            }
        });

        btnCreate = findViewById(R.id.btnCreateMain);
        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent create = new Intent(MainActivity.this, CreateActivity.class);
                startActivity(create);
                finish();
            }
        });

        btnUpdate = findViewById(R.id.btnUpdateMain);
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent update = new Intent(MainActivity.this, UpdateActivity.class);
                startActivity(update);
                finish();
            }
        });

        btnDelete  = findViewById(R.id.btnDeleteMain);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent delete  = new Intent(MainActivity.this, DeleteActivity.class);
                startActivity(delete);
                finish();
            }
        });
    }
}
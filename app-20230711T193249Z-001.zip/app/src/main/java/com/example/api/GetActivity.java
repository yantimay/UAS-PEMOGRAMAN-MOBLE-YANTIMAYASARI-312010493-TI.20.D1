package com.example.api;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.api.api.ApiClient;
import com.example.api.model.Phone;
import com.example.api.service.PhoneService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class GetActivity extends AppCompatActivity {

    private EditText edtId;
    private Button btnGet;
    private TextView tvResult;
    private ImageView ivBack;
    private PhoneService phoneService;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get);

        edtId = findViewById(R.id.edtGetId);
        tvResult = findViewById(R.id.tvResult);
        phoneService = ApiClient.getClient().create(PhoneService.class);

        ivBack = findViewById(R.id.ivGetBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(GetActivity.this, MainActivity.class);
                startActivity(back);
                finish();
            }
        });

        btnGet = findViewById(R.id.btnGet);
        btnGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int phoneId = Integer.parseInt(edtId.getText().toString());
                getPhoneById(phoneId);
            }
        });

    }

    private void getPhoneById(int phoneId) {
        Call<Phone> call = phoneService.getPhoneById(phoneId);
        call.enqueue(new Callback<Phone>() {
            @Override
            public void onResponse(Call<Phone> call, Response<Phone> response) {
                if (response.isSuccessful()) {
                    Phone phone = response.body();
                    if (phone != null) {
                        StringBuilder result = new StringBuilder();
                        result.append("ID: ").append(phone.getId())
                                .append("\nPhone Name: ").append(phone.getPhoneName())
                                .append("\nPrice: ").append(phone.getPrice());
                        tvResult.setText(result.toString());
                    } else {
                        tvResult.setText("Phone not found");
                    }
                } else {
                    tvResult.setText("Failed to get phone. Error code: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<Phone> call, Throwable t) {
                tvResult.setText("Failed to get phone. Error message: " + t.getMessage());
            }
        });
    }
}
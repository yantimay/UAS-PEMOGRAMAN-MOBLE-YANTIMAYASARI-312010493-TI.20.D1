package com.example.api.service;

import com.example.api.model.Phone;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface PhoneService {

    @GET("/phones/{id}")
    Call<Phone> getPhoneById(@Path("id") Integer id);

    @POST("/phones/")
    Call<Phone> ceatePhone(@Body Phone phone);

    @PUT("/phones/{id}")
    Call<Phone> updatePhone(@Path("id") Integer id, @Body Phone phone);

    @DELETE("/phones/{id}")
    Call<Void> deletePhone(@Path("id") Integer id);
}

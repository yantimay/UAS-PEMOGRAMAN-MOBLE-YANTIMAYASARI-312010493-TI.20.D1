package com.example.api;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.api.api.ApiClient;
import com.example.api.model.Phone;
import com.example.api.service.PhoneService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DeleteActivity extends AppCompatActivity {

    private EditText edtId;
    private Button btnDelete;
    private PhoneService phoneService;
    private ImageView ivBack;
    
    
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        
        edtId = findViewById(R.id.edtDeletId);
        
        phoneService = ApiClient.getClient().create(PhoneService.class);

        ivBack  = findViewById(R.id.ivDeleteBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(DeleteActivity.this, MainActivity.class);
                startActivity(back);
                finish();
            }
        });
        
        btnDelete = findViewById(R.id.btndelete);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deletePhone();
            }
        });
        
        
    }

    private void deletePhone() {
        int phoneId = Integer.parseInt(edtId.getText().toString());
        Call<Void> call = phoneService.deletePhone(phoneId);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(DeleteActivity.this, "Berhasil Menghapus Data", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(DeleteActivity.this, "Gagagl Menghapus Data, error : " + response.code(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(DeleteActivity.this, "Gagal Menghapus Data, error message: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}